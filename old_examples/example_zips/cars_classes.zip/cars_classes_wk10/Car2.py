#first you import the super (parent) class
from Car import Car

class Car2(Car):#Car2 inherits car

     def __init__(self):
         super().__init__()#super refers to the parent class, I need to do this to get the properties
         self.seats = 0

     def setSeats(self,num):
        self.seats = num

     def getSeats(self):
         return "The number of seats is "+str(self.seats)

     def getDetails(self):
         return self.color+" "+self.make+" "+self.model+" "+str(self.seats)+" seats"

