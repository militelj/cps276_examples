class Car:
    def __init__(self):
        #these properties do not have to have assigned values
        self.make = "Honda"
        self.model = "CRV"
        self.color = "Dark Blue"
        self.engine = "4 cylinder"

    def setColor(self,color):
        self.color = color

    def setModel(self,model):
        self.model = model

    def setMake(self,make):
        self.make = make

    def setEngine(self,engine):
        self.engine = engine

    def getColor(self):
        return self.color

    def getModel(self):
        return self.model

    def getMake(self):
        return self.make

    def getEngine(self):
        return self.engine

    def getDetails(self):
        return self.color+" "+self.make+" "+self.model



