#import my Car2 file
from Car2 import Car2

car = Car2()
car.setSeats(4)#sets the seats new method not in the parent class
print(car.getModel())#gets the parent model method
print(car.getDetails())#overwrote getDetails
