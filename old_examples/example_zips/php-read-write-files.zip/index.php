<?php
//include files
include_once('classes/Validation.php');

$acknowledgement = "&nbsp;";
$output = "";


//If the "Add Name To File" button was click the following is done.
if (isset($_POST['write'])){
	/*
	Anything created outside the function must be global to be used inside a function.
    or passed via the parameter. Also any variables created inside the function that are
    set as global can be used outside the function.
    */
    global $errorArray;
    //global $Validation;
    //initiate object of the validation class
    $Validation = new Validation();
    
    //This checks the entry and if there is an error puts the error message into the errorArray
    //NOTE: to avoid writing the $_POST[] you could assign each post to a variable.
    $errorArray[0] = $Validation->checkForBlanks($_POST['fname']);
    $errorArray[1] = $Validation->checkForBlanks($_POST['lname']);
    
    /*
    If everything checks out I open a file and set it to "a" which means append. What I want to do is append my content
    to the end of the existing file content.  In this example I have a list of names and every name I add needs to go to
    the bottom of the names list.  When that step is complete I clear out the name variables so they do not stay in the text
    boxes after the name has been written.  Also, I add some text to the acknowledgment so the user sees that the name was added.
    */
    if (!$Validation->checkErrors()){
    	/*
    	I do this to create a CSV (comma seperated values) structure.  Each value is seperated by a comma and ends with a line break
    	(\n)
    	*/
    	$content = $_POST['fname'].",".$_POST['lname']."\n";
    	$file = fopen("files/names.txt","a") or die("Cannot Open File");
    	fwrite($file,$content);
    	fclose($file);
    	//I clear my post values because I used those below in the html
    	$_POST['fname'] = "";
    	$_POST['lname'] = "";
    	//create my acknowledgement
    	$acknowledgement = "Name has been added";
    	
    }
}
/*
If the "Read File" button is clicked the following is done.

I first get the contents of the file using the file() function. That function reads the entire file and puts each line into an array.
I loop through the array (called $file) and explode on each comma creating a $tempArr of each line.  I then remove the extra space from
the last name and put the last name first, then a comma and space, and the first name into another array named $sortedArr.  Now I have an
array that has the lastname, firstname format.  I sort that array, then loop through it putting each line into the $output variable. The
result is a list of names, sorted by lastname then first name.
 

There are other ways of doing this. I could have just entered the names into the file using the last name first format.  But this is an
example showing how you can change stuctures.
*/
if (isset($_POST['read'])){
	$sortedArr = array();
	$file = file("files/names.txt");
	foreach($file as $v){
		$tempArr = explode(",",$v);
		//the \n creates an extra space at the end of the last name, this removes it.
		$tempArr[1] = substr($tempArr[1],0,-1);
		$str = "$tempArr[1], $tempArr[0]";
		array_push($sortedArr,$str);
	}
	//for sorting lower case
	usort($sortedArr,"strcasecmp");
	
	//for just sorting
	//sort($sortedArr);
	foreach($sortedArr as $v){
		$output .= "<p>$v</p>";
	}
	
}
/*
This is very simple way to clear a file. I open the file with the "w" flag (which means write or overwrite if the file has content), 
then I write an empty string.
*/
if (isset($_POST['clear'])){
	$file = fopen("files/names.txt","w") or die ("Cannot Open File");
	fwrite($file,"");
	fclose($file);
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>Contacts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style>
<!--
.error{color: red; font-size: 11px;} 
-->
</style>
</head>
<body>
<p><?php  echo $acknowledgement; ?></p>
<form method="post" action="" >
		<p><label for="fname">First Name</label><?php if(isset($errorArray[0])){echo "<span class='error'>{$errorArray[0]}</span>";} ?><br />
		<input type="text" id="fname" name="fname" tabindex="10" value="<?php if(isset($_POST['fname'])){echo $_POST['fname'];} ?>" /></p>
		
		<p><label for="lname">Last Name</label><?php if(isset($errorArray[1])){echo "<span class='error'>{$errorArray[1]}</span>";} ?><br />
		<input type="text" id="lname" name="lname" tabindex="20" value="<?php if(isset($_POST['lname'])){$_POST['lname'];} ?>" /></p>

		<p>
		<input type="submit" name="write" value="Add Name To File" tabindex="30" />
		<input type="submit" name="read" value="Read File" tabindex="40" />
		<input type="submit" name="clear" value="Clear File" tabindex="50" />
		</p>
	</form>
	<?php echo $output; ?>
</body>
</html>

	
