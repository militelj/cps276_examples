<?php
echo "<h1>Hello Class! Welcome to PHP</h1>";

?>