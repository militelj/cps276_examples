<?php
//Need to include the Car.php file to use the class.
include_once('Car.php');
class CarSubClass extends Car{
	//sets the properties to private and the datatype to string
    private $seats;
        
    public function __construct(){
    	parent::__construct();//needs to be called so we can inherite the constructor, otherwise it will overwrite it.
    	$this->seats = 4;
    }
    
    public function setSeats($num){
    	$this->seats=$$num;
    }  
    
    public function getSeats(){
    	return $this->seats;
    }  
 
	public function getDetails(){
		//I have to call the get functions of the parent because I cannot access the private properties directly
		return $this->getColor()." ".$this->getMake()." ".$this->getModel()." ".$this->seats." seats";
	}
}
