<?php
class Car{
	//sets the properties to private and the datatype to string
    private $make;
    private $model;
    private $color;
    private $engine;

    
    public function __construct(){
    	 //assigns values to the properties. Constructor functions are used to set things up.
        $this->make = "Honda";
        $this->model = "CRV";
        $this->color = "Dark Blue";
        $this->engine = "4 cylinder";
    }
     
    public function setColor($color){
    	$this->color=$color;
    }  
    
    public function setModel($model){
    	$this->model=$color;
    }  
    
    public function setMake($make){
    	$this->make=$make;
    }  
    
    public function setEngine($engine){
    	$this->engine=$engine;
    }   
	
	public function getColor(){
		return $this->color;
	}
	
	public function getModel(){
		return $this->model;
	}
	
	public function getMake(){
		return $this->make;
	}
	
	public function getEngine(){
		return $this->engine;
	}

	public function getDetails(){
		return $this->color." ".$this->make." ".$this->model;
	}
}
